import { Mutex } from 'async-mutex';
import { format } from 'date-fns';

class Log {
    static lock = new Mutex();

    static async _log(level, prefix, message) {
        const timestamp = format(new Date(), 'HH:mm:ss');
        const logMessage = `[${timestamp}] ${prefix} ${message}`;

        await Log.lock.runExclusive(async () => {
            console.log(logMessage);
        });
    }

    static async Success(message, prefix = "(+)", color = "SUCCESS") {
        await Log._log("SUCCESS", `${prefix}`, message);
    }

    static async Error(message, prefix = "(-)", color = "ERROR") {
        await Log._log("ERROR", `${prefix}`, message);
    }

    static async Debug(message, prefix = "(#)", color = "DEBUG") {
        await Log._log("DEBUG", `${prefix}`, message);
    }

    static async Info(message, prefix = "(?)", color = "INFO") {
        await Log._log("INFO", `${prefix}`, message);
    }

    static async Warning(message, prefix = "(!)", color = "WARNING") {
        await Log._log("WARNING", `${prefix}`, message);
    }
}

export { Log };