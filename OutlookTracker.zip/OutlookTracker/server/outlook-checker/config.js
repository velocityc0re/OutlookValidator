export default {
    threads: 500,           // High-speed thread count as per GitHub
    retry_limit: 1,         // Number of retries if check fails
    proxy_type: "HTTP",     // Proxy type: HTTP | SOCKS4 | SOCKS5
    inbox_filter: ["", "", ""], // Domain filter for inbox checking
    timeout: 10000,         // Request timeout in milliseconds
    delay: 0               // Delay between requests (0 for max speed)
};