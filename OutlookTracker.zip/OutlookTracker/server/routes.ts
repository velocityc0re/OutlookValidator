import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

// Import the real Outlook checker from your GitHub
import { checkAccount } from "./outlook-checker/index.js";
import config from "./outlook-checker/config.js";

export async function registerRoutes(app: Express): Promise<Server> {
  // Server-Sent Events for real-time progress updates
  app.get("/api/check-progress/:sessionId", (req, res) => {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Cache-Control'
    });

    const sessionId = req.params.sessionId;
    // Store the response object for this session
    global.sseConnections = global.sseConnections || new Map();
    global.sseConnections.set(sessionId, res);

    req.on('close', () => {
      global.sseConnections.delete(sessionId);
    });
  });

  // Outlook Account Checker API - Real implementation from your GitHub
  app.post("/api/check-accounts", async (req, res) => {
    try {
      const { accounts, proxy, proxyType = 'http', retryLimit = 1, sessionId } = req.body;
      
      if (!accounts || !Array.isArray(accounts)) {
        return res.status(400).json({ error: "Accounts array is required" });
      }

      console.log(`Starting check for ${accounts.length} accounts using real GitHub implementation`);

      const results = {
        total: accounts.length,
        valid: [] as string[],
        invalid: [] as string[],
        locked: [] as string[],
        twofa: [] as string[],
        failed: [] as string[],
        progress: 0
      };

      // Process accounts using multi-threading (high-speed as per GitHub)
      const threadCount = Math.min(config.threads, accounts.length);
      console.log(`Using ${threadCount} threads for high-speed checking (GitHub configuration)`);
      
      const chunks = [];
      const chunkSize = Math.ceil(accounts.length / threadCount);
      
      for (let i = 0; i < accounts.length; i += chunkSize) {
        chunks.push(accounts.slice(i, i + chunkSize));
      }

      let completed = 0;
      const processChunk = async (chunk: string[], chunkIndex: number) => {
        for (const account of chunk) {
          const [email, password] = account.split(':');
          
          if (!email || !password) {
            results.failed.push(account);
            completed++;
            continue;
          }

          try {
            const result = await checkAccount(email.trim(), password.trim(), proxy, proxyType, retryLimit);
            
            switch (result.status) {
              case 'valid':
                results.valid.push(result.account);
                console.log(`✓ Valid: ${result.account}`);
                break;
              case 'invalid':
                results.invalid.push(result.account);
                console.log(`✗ Invalid: ${result.account}`);
                break;
              case 'locked':
                results.locked.push(result.account);
                console.log(`🔒 Locked: ${result.account}`);
                break;
              case '2fa':
                results.twofa.push(result.account);
                console.log(`🔐 2FA: ${result.account}`);
                break;
              default:
                results.failed.push(result.account);
                console.log(`❌ Failed: ${result.account} (${result.status})`);
                break;
            }
          } catch (error) {
            console.error(`Error checking account ${email}:`, error);
            results.failed.push(account);
          }

          completed++;
          results.progress = (completed / accounts.length) * 100;
          
          // Send real-time progress updates via SSE
          if (sessionId && global.sseConnections && global.sseConnections.has(sessionId)) {
            const sseRes = global.sseConnections.get(sessionId);
            const progressData = {
              progress: results.progress,
              valid: results.valid.length,
              invalid: results.invalid.length,
              locked: results.locked.length,
              twofa: results.twofa.length,
              failed: results.failed.length,
              total: accounts.length,
              completed: completed
            };
            sseRes.write(`data: ${JSON.stringify(progressData)}\n\n`);
          }
          
          // Log progress regularly
          if (completed % 10 === 0 || completed === accounts.length) {
            console.log(`Progress: ${results.progress.toFixed(1)}% - Valid: ${results.valid.length}, Invalid: ${results.invalid.length}, Locked: ${results.locked.length}, 2FA: ${results.twofa.length}, Failed: ${results.failed.length}`);
          }
        }
      };

      // Execute all chunks concurrently for high-speed processing
      await Promise.all(chunks.map((chunk, index) => processChunk(chunk, index)));

      console.log(`Checking completed! Final results:`, {
        total: results.total,
        valid: results.valid.length,
        invalid: results.invalid.length,
        locked: results.locked.length,
        twofa: results.twofa.length,
        failed: results.failed.length
      });

      res.json(results);
    } catch (error) {
      console.error('Account checking error:', error);
      res.status(500).json({ error: "Internal server error during account checking" });
    }
  });

  // Single account check endpoint using your real implementation
  app.post("/api/check-account", async (req, res) => {
    try {
      const { email, password, proxy, proxyType = 'http', retryLimit = 1 } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ error: "Email and password are required" });
      }

      const result = await checkAccount(email, password, proxy, proxyType, retryLimit);
      res.json(result);
    } catch (error) {
      console.error('Single account check error:', error);
      res.status(500).json({ error: "Internal server error during account checking" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
