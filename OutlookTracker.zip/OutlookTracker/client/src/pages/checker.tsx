import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Link } from 'wouter';

interface CheckResult {
  total: number;
  valid: number;
  invalid: number;
  locked: number;
  twofa: number;
  progress: number;
  validAccounts: string[];
  completed: boolean;
}

export default function Checker() {
  const [accounts, setAccounts] = useState('');
  const [isChecking, setIsChecking] = useState(false);
  const [result, setResult] = useState<CheckResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        setAccounts(content);
        toast({
          title: "File uploaded",
          description: `Loaded ${content.split('\n').filter(line => line.trim()).length} accounts`,
        });
      };
      reader.readAsText(file);
    }
  };

  const realChecking = async () => {
    const accountList = accounts.split('\n').filter(line => line.trim() && line.includes(':'));
    
    if (accountList.length === 0) {
      toast({
        title: "No accounts found",
        description: "Please enter accounts in email:password format",
        variant: "destructive",
      });
      return;
    }

    setIsChecking(true);
    const sessionId = Date.now().toString();
    
    setResult({
      total: accountList.length,
      valid: 0,
      invalid: 0,
      locked: 0,
      twofa: 0,
      progress: 0,
      validAccounts: [],
      completed: false,
    });

    // Setup real-time progress updates via Server-Sent Events
    const eventSource = new EventSource(`/api/check-progress/${sessionId}`);
    
    eventSource.onmessage = (event) => {
      try {
        const progressData = JSON.parse(event.data);
        setResult(prev => prev ? {
          ...prev,
          progress: progressData.progress,
          valid: progressData.valid,
          invalid: progressData.invalid,
          locked: progressData.locked,
          twofa: progressData.twofa,
          total: progressData.total,
          completed: progressData.completed >= progressData.total
        } : null);
      } catch (error) {
        console.error('SSE parsing error:', error);
      }
    };

    try {
      toast({
        title: "Starting high-speed verification",
        description: `Processing ${accountList.length} accounts with up to 500 threads using your GitHub source code`,
      });
      
      console.log(`Starting check for ${accountList.length} accounts with session ${sessionId}`);
      const response = await fetch('/api/check-accounts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          accounts: accountList,
          retryLimit: 1,
          sessionId: sessionId
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('API Error:', errorText);
        throw new Error(`HTTP error! status: ${response.status} - ${errorText}`);
      }

      const data = await response.json();
      console.log('Final results received:', data);
      
      setResult({
        total: data.total,
        valid: data.valid.length,
        invalid: data.invalid.length,
        locked: data.locked.length,
        twofa: data.twofa.length,
        progress: 100,
        validAccounts: data.valid,
        completed: true,
      });

      toast({
        title: "High-speed checking completed!",
        description: `Processed ${data.total} accounts - ${data.valid.length} valid, ${data.invalid.length} invalid, ${data.locked.length} locked, ${data.twofa.length} 2FA`,
      });
    } catch (error) {
      console.error('Checking error:', error);
      toast({
        title: "Checking Error",
        description: error instanceof Error ? error.message : "Failed to check accounts using real Microsoft APIs with high-speed threading",
        variant: "destructive",
      });
      setResult(prev => prev ? { ...prev, completed: true, progress: 100 } : null);
    } finally {
      eventSource.close();
      setIsChecking(false);
    }
  };

  const downloadResults = () => {
    if (!result?.validAccounts.length) return;
    
    const content = result.validAccounts.join('\n');
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'valid_accounts.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const copyToClipboard = () => {
    if (!result?.validAccounts.length) return;
    
    navigator.clipboard.writeText(result.validAccounts.join('\n'));
    toast({
      title: "Copied to clipboard",
      description: "Valid accounts copied to clipboard",
    });
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Navigation */}
      <nav className="bg-gray-900/90 backdrop-blur-xl border-b border-gray-800 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center">
              <i className="fas fa-shield-alt text-ms-blue text-2xl mr-3"></i>
              <span className="text-xl font-semibold">Outlook Checker</span>
            </Link>
            <Link href="/">
              <Button variant="outline" className="border-gray-600 hover:border-ms-blue">
                <i className="fas fa-arrow-left mr-2"></i>
                Back to Home
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4">
            <span className="bg-gradient-to-r from-ms-blue via-electric-blue to-cyber-green bg-clip-text text-transparent">
              Account Checker
            </span>
          </h1>
          <p className="text-xl text-gray-400">Upload or paste your account list to begin verification</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Input Section */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-ms-blue">Account Input</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2">Upload File</label>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".txt,.csv"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <Button
                  onClick={() => fileInputRef.current?.click()}
                  variant="outline"
                  className="w-full border-gray-600 hover:border-ms-blue"
                  disabled={isChecking}
                >
                  <i className="fas fa-upload mr-2"></i>
                  Choose File
                </Button>
              </div>

              <div className="text-center text-gray-400">or</div>

              <div>
                <label className="block text-sm font-medium mb-2">Paste Accounts</label>
                <Textarea
                  placeholder="email@outlook.com:password123&#10;user@hotmail.com:mypassword&#10;..."
                  value={accounts}
                  onChange={(e) => setAccounts(e.target.value)}
                  className="min-h-[200px] bg-gray-900 border-gray-600 focus:border-ms-blue"
                  disabled={isChecking}
                />
                <p className="text-sm text-gray-400 mt-2">
                  Format: email:password (one per line)
                </p>
              </div>

              <Button
                onClick={realChecking}
                disabled={isChecking || !accounts.trim()}
                className="w-full bg-gradient-to-r from-ms-blue to-ms-blue-dark hover:from-ms-blue-dark hover:to-ms-blue"
              >
                {isChecking ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    Checking...
                  </>
                ) : (
                  <>
                    <i className="fas fa-play mr-2"></i>
                    Start Checking
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Status Panel */}
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle className="text-ms-blue">Checking Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {result ? (
                <>
                  {/* Progress Bar */}
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Progress</span>
                      <span>{Math.round(result.progress)}%</span>
                    </div>
                    <Progress value={result.progress} className="h-3" />
                  </div>

                  {/* Statistics */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-gray-900 rounded-lg p-4 text-center">
                      <div className="text-2xl font-bold text-white">{result.total}</div>
                      <div className="text-sm text-gray-400">Total</div>
                    </div>
                    <div className="bg-gray-900 rounded-lg p-4 text-center">
                      <div className="text-2xl font-bold text-cyber-green">{result.valid}</div>
                      <div className="text-sm text-gray-400">Valid</div>
                    </div>
                    <div className="bg-gray-900 rounded-lg p-4 text-center">
                      <div className="text-2xl font-bold text-red-400">{result.invalid}</div>
                      <div className="text-sm text-gray-400">Invalid</div>
                    </div>
                    <div className="bg-gray-900 rounded-lg p-4 text-center">
                      <div className="text-2xl font-bold text-yellow-400">{result.locked}</div>
                      <div className="text-sm text-gray-400">Locked</div>
                    </div>
                    <div className="bg-gray-900 rounded-lg p-4 text-center col-span-2">
                      <div className="text-2xl font-bold text-blue-400">{result.twofa}</div>
                      <div className="text-sm text-gray-400">2FA Protected</div>
                    </div>
                  </div>

                  {/* Results Actions */}
                  {result.completed && (
                    <div className="space-y-4">
                      <div className="text-center">
                        <div className="text-lg font-semibold text-cyber-green mb-2">
                          ✓ Checking Complete!
                        </div>
                        <div className="text-sm text-gray-400">
                          {result.valid > 0 ? `Found ${result.valid} valid accounts` : "Checking finished - no valid accounts found"}
                        </div>
                      </div>
                      
                      {result.validAccounts.length > 0 && (
                        <div className="flex gap-3">
                          <Button
                            onClick={copyToClipboard}
                            variant="outline"
                            className="flex-1 border-gray-600 hover:border-cyber-green"
                          >
                            <i className="fas fa-copy mr-2"></i>
                            Copy Results
                          </Button>
                          <Button
                            onClick={downloadResults}
                            className="flex-1 bg-gradient-to-r from-cyber-green to-green-500 hover:from-green-500 hover:to-cyber-green text-gray-900"
                          >
                            <i className="fas fa-download mr-2"></i>
                            Download File
                          </Button>
                        </div>
                      )}
                    </div>
                  )}
                </>
              ) : (
                <div className="text-center text-gray-400 py-12">
                  <i className="fas fa-chart-line text-4xl mb-4"></i>
                  <p>Upload accounts to see checking progress</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Info Panel */}
        <Card className="mt-8 bg-gradient-to-r from-blue-900/20 to-cyan-900/20 border-blue-800/50">
          <CardContent className="p-6">
            <h4 className="text-lg font-semibold mb-2 text-electric-blue">ℹ️ How it works</h4>
            <ul className="text-gray-300 text-sm space-y-1">
              <li>• Upload a .txt file or paste accounts in email:password format</li>
              <li>• The checker will verify each account and categorize the results</li>
              <li>• Valid accounts can be copied to clipboard or downloaded as a file</li>
              <li>• Progress is shown in real-time with detailed statistics</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}