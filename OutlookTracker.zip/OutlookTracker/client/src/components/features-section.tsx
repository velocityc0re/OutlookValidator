import { Card, CardContent } from '@/components/ui/card';

export default function FeaturesSection() {
  const features = [
    {
      icon: 'fas fa-tachometer-alt',
      title: 'High-Speed Processing',
      description: 'Up to 500 concurrent threads for lightning-fast account verification',
      metric: '500 threads/sec',
      color: 'text-ms-blue'
    },
    {
      icon: 'fas fa-bullseye',
      title: '99.9% Accuracy',
      description: 'Industry-leading detection rate for all account states',
      metric: '99.9% precision',
      color: 'text-ms-blue'
    },
    {
      icon: 'fas fa-shield-alt',
      title: 'Proxy Support',
      description: 'HTTP, SOCKS4, and SOCKS5 proxy compatibility',
      metric: '3 proxy types',
      color: 'text-ms-blue'
    },
    {
      icon: 'fas fa-search',
      title: 'Smart Detection',
      description: 'Identifies locked, 2FA, invalid, and valid accounts',
      metric: '4 account states',
      color: 'text-ms-blue'
    },
    {
      icon: 'fas fa-filter',
      title: 'Inbox Filter',
      description: 'Advanced filtering with custom domain configuration',
      metric: 'Paid feature',
      color: 'text-ms-blue'
    },
    {
      icon: 'fas fa-mobile-alt',
      title: 'IMAP Enabler',
      description: 'Thunderbird Mobile API integration for IMAP access',
      metric: 'Paid feature',
      color: 'text-ms-blue'
    }
  ];

  return (
    <section id="features" className="py-20 bg-gray-800/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Advanced Features</h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Cutting-edge technology for professional account verification and security analysis
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card 
              key={index}
              className="group bg-gradient-to-br from-gray-800 to-gray-900 border-gray-700 hover:border-ms-blue transition-all hover:transform hover:scale-105 hover:shadow-2xl hover:shadow-blue-500/10"
            >
              <CardContent className="p-8">
                <div className={`${feature.color} group-hover:text-electric-blue text-4xl mb-4 transition-colors`}>
                  <i className={feature.icon}></i>
                </div>
                <h3 className="text-xl font-semibold mb-4">{feature.title}</h3>
                <p className="text-gray-400 mb-4">{feature.description}</p>
                <div className="text-sm text-cyber-green font-mono">{feature.metric}</div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
