import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export default function PricingSection() {
  const pricingPlans = [
    {
      name: 'Free Version',
      price: '$0',
      description: 'Perfect for learning and testing',
      features: [
        { text: 'Request-based processing', included: true },
        { text: 'Up to 500 threads', included: true },
        { text: '99.9% detection rate', included: true },
        { text: 'Proxy support (HTTP/SOCKS)', included: true },
        { text: 'Recordnotice bypass', included: false },
        { text: 'IMAP enabler', included: false }
      ],
      buttonText: 'Try Free Version',
      buttonClass: 'bg-gradient-to-r from-cyber-green to-green-500 hover:from-green-500 hover:to-cyber-green text-gray-900',
      cardClass: 'bg-gradient-to-br from-gray-800 to-gray-900 border-gray-700'
    },
    {
      name: 'License Key',
      price: '$99',
      description: 'Lifetime access to premium features',
      popular: true,
      features: [
        { text: 'All free version features', included: true },
        { text: 'Recordnotice bypass', included: true },
        { text: 'IMAP enabler (Thunderbird)', included: true },
        { text: 'Inbox filter', included: true },
        { text: 'Priority support', included: true },
        { text: 'Lifetime updates', included: true }
      ],
      buttonText: 'Get License Key',
      buttonClass: 'bg-white text-ms-blue hover:scale-105 hover:shadow-lg',
      cardClass: 'bg-gradient-to-br from-ms-blue to-ms-blue-dark border-ms-blue transform scale-105',
      textColor: 'text-blue-50'
    },
    {
      name: 'Full Source',
      price: '$250',
      description: 'Complete source code access',
      features: [
        { text: 'All premium features', included: true },
        { text: 'Complete source code', included: true },
        { text: 'Modification rights', included: true },
        { text: 'Commercial license', included: true },
        { text: 'Developer support', included: true },
        { text: 'Custom modifications', included: true }
      ],
      buttonText: 'Buy Source Code',
      buttonClass: 'bg-gradient-to-r from-electric-blue to-blue-500 hover:from-blue-500 hover:to-electric-blue text-white',
      cardClass: 'bg-gradient-to-br from-gray-800 to-gray-900 border-gray-700'
    }
  ];

  return (
    <section id="pricing" className="py-20 bg-gray-800/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Choose Your Version</h2>
          <p className="text-xl text-gray-400">Professional features for every security need</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {pricingPlans.map((plan, index) => (
            <Card key={index} className={`${plan.cardClass} relative`}>
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-electric-blue text-gray-900 px-6 py-2 rounded-full text-sm font-bold">
                  POPULAR
                </div>
              )}
              <CardContent className="p-8">
                <div className="text-center mb-8">
                  <h3 className={`text-2xl font-bold mb-2 ${plan.textColor || 'text-white'}`}>
                    {plan.name}
                  </h3>
                  <div className={`text-4xl font-bold mb-4 ${plan.popular ? 'text-white' : 'text-ms-blue'}`}>
                    {plan.price}
                  </div>
                  <p className={plan.textColor || 'text-gray-400'}>{plan.description}</p>
                </div>
                
                <ul className={`space-y-4 mb-8 ${plan.textColor || 'text-white'}`}>
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <i className={`${feature.included ? 'fas fa-check' : 'fas fa-times'} ${
                        feature.included ? 'text-white' : 'text-gray-500'
                      } mr-3`}></i>
                      <span className={feature.included ? '' : 'text-gray-500'}>
                        {feature.text}
                      </span>
                    </li>
                  ))}
                </ul>
                
                {index === 0 ? (
                  <a href="/checker">
                    <Button className={`w-full ${plan.buttonClass} font-semibold py-3 transition-all transform hover:scale-105`}>
                      {plan.buttonText}
                    </Button>
                  </a>
                ) : (
                  <Button className={`w-full ${plan.buttonClass} font-semibold py-3 transition-all transform hover:scale-105`}>
                    {plan.buttonText}
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Special Offer */}
        <div className="text-center mt-12">
          <Card className="bg-gradient-to-r from-cyber-green/20 to-electric-blue/20 border-cyber-green/50 max-w-2xl mx-auto">
            <CardContent className="p-6">
              <h4 className="text-xl font-bold mb-2 text-cyber-green">🎯 Special Offer</h4>
              <p className="text-gray-300">
                Free release at <span className="font-bold text-white">200 GitHub stars</span>
                <br />
                Currently at <span className="font-bold text-ms-blue">97 stars</span> - Help us reach the goal!
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
