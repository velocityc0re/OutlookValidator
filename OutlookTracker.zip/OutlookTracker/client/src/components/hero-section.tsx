import { useCounter } from '@/hooks/use-counter';
import { useIntersectionObserver } from '@/hooks/use-intersection-observer';
import { Button } from '@/components/ui/button';

export default function HeroSection() {
  const { ref, hasIntersected } = useIntersectionObserver();
  
  const detectionRate = useCounter(99.9, 2000, hasIntersected);
  const maxThreads = useCounter(500, 2000, hasIntersected);
  const githubStars = useCounter(97, 2000, hasIntersected);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900"></div>
      <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 via-transparent to-cyan-500/10 animate-gradient"></div>
      
      {/* Floating Elements */}
      <div className="absolute top-20 left-10 w-20 h-20 bg-ms-blue/20 rounded-full animate-float"></div>
      <div className="absolute top-40 right-20 w-16 h-16 bg-cyber-green/20 rounded-full animate-float" style={{animationDelay: '2s'}}></div>
      <div className="absolute bottom-40 left-1/4 w-12 h-12 bg-electric-blue/20 rounded-full animate-float" style={{animationDelay: '4s'}}></div>

      <div ref={ref} className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Microsoft Technology Image */}
        <img 
          src="https://images.unsplash.com/photo-1633356122544-f134324a6cee?ixlib=rb-4.0.3&auto=format&fit=crop&w=120&h=120" 
          alt="Microsoft Technology" 
          className="mx-auto mb-8 w-20 h-20 rounded-2xl shadow-2xl" 
        />
        
        <h1 className="text-4xl md:text-6xl font-bold mb-6">
          <span className="bg-gradient-to-r from-ms-blue via-electric-blue to-cyber-green bg-clip-text text-transparent">
            Outlook Account Checker
          </span>
        </h1>
        
        <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto">
          Professional Microsoft Outlook & Hotmail account verification tool with{' '}
          <span className="text-cyber-green font-semibold">99.9% detection accuracy</span>
        </p>

        {/* Key Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12 max-w-4xl mx-auto">
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700">
            <div className="text-3xl font-bold text-cyber-green mb-2">
              {detectionRate === 99.9 ? '99.9' : detectionRate.toFixed(1)}
            </div>
            <div className="text-gray-400">Detection Rate %</div>
          </div>
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700">
            <div className="text-3xl font-bold text-electric-blue mb-2">
              {Math.floor(maxThreads)}
            </div>
            <div className="text-gray-400">Max Threads</div>
          </div>
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 border border-gray-700">
            <div className="text-3xl font-bold text-ms-blue mb-2">
              {Math.floor(githubStars)}
            </div>
            <div className="text-gray-400">GitHub Stars</div>
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
          <a href="/checker">
            <Button 
              className="bg-gradient-to-r from-ms-blue to-ms-blue-dark hover:from-ms-blue-dark hover:to-ms-blue px-8 py-4 text-lg h-auto transition-all transform hover:scale-105 shadow-lg hover:shadow-blue-500/25"
            >
              <i className="fas fa-download mr-2"></i>
              Try Free Version
            </Button>
          </a>
          <Button 
            variant="outline"
            onClick={() => scrollToSection('demo')}
            className="border-gray-600 hover:border-ms-blue px-8 py-4 text-lg h-auto transition-all hover:bg-ms-blue/10"
          >
            <i className="fas fa-play mr-2"></i>
            View Demo
          </Button>
        </div>

        {/* GitHub Stats */}
        <div className="flex justify-center items-center space-x-6 text-gray-400">
          <div className="flex items-center">
            <i className="fab fa-github mr-2"></i>
            <span>97 stars</span>
          </div>
          <div className="flex items-center">
            <i className="fas fa-code-branch mr-2"></i>
            <span>11 forks</span>
          </div>
          <div className="flex items-center">
            <i className="fas fa-balance-scale mr-2"></i>
            <span>GPL-3.0 License</span>
          </div>
        </div>
      </div>
    </section>
  );
}
