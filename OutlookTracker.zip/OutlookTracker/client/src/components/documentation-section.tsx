import { Card, CardContent } from '@/components/ui/card';

export default function DocumentationSection() {
  const fileStructure = [
    { type: 'folder', name: 'input/', icon: 'fas fa-folder', color: 'text-yellow-500' },
    { type: 'file', name: 'combolist.txt', icon: 'fas fa-file', color: 'text-blue-400', comment: '# email:password', indent: true },
    { type: 'file', name: 'proxies.txt', icon: 'fas fa-file', color: 'text-blue-400', comment: '# proxy list', indent: true },
    { type: 'folder', name: 'output/', icon: 'fas fa-folder', color: 'text-yellow-500' },
    { type: 'file', name: 'valid.txt', icon: 'fas fa-file', color: 'text-green-400', indent: true },
    { type: 'file', name: 'invalid.txt', icon: 'fas fa-file', color: 'text-red-400', indent: true }
  ];

  return (
    <section id="documentation" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Documentation</h2>
          <p className="text-xl text-gray-400">Complete setup guide and configuration options</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Installation Guide */}
          <div className="space-y-6">
            <h3 className="text-2xl font-bold mb-6 text-ms-blue">Quick Start Guide</h3>
            
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6">
                <h4 className="text-lg font-semibold mb-4 text-electric-blue">Installation</h4>
                <div className="bg-gray-900 rounded-lg p-4 font-mono text-sm">
                  <div className="text-gray-400 mb-2"># Install Node.js</div>
                  <div className="text-white">npm install</div>
                  <div className="text-gray-400 mt-4 mb-2"># Configure files</div>
                  <div className="text-white">edit input/combolist.txt</div>
                  <div className="text-white">edit input/proxies.txt</div>
                  <div className="text-gray-400 mt-4 mb-2"># Run the checker</div>
                  <div className="text-white">node index.js</div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6">
                <h4 className="text-lg font-semibold mb-4 text-electric-blue">File Structure</h4>
                <div className="space-y-2 font-mono text-sm">
                  {fileStructure.map((item, index) => (
                    <div key={index} className={`flex items-center ${item.indent ? 'ml-4' : ''}`}>
                      <i className={`${item.icon} ${item.color} mr-2`}></i>
                      <span className="text-gray-300">{item.name}</span>
                      {item.comment && (
                        <span className="text-gray-500 ml-2">{item.comment}</span>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Configuration */}
          <div className="space-y-6">
            <h3 className="text-2xl font-bold mb-6 text-ms-blue">Configuration</h3>
            
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6">
                <h4 className="text-lg font-semibold mb-4 text-electric-blue">config.js</h4>
                <div className="bg-gray-900 rounded-lg p-4 font-mono text-sm">
                  <div className="text-purple-400">module.exports = {'{'}</div>
                  <div className="ml-4 text-gray-300">
                    <div><span className="text-blue-400">threads:</span> <span className="text-yellow-300">100</span>,</div>
                    <div><span className="text-blue-400">retry_limit:</span> <span className="text-yellow-300">1</span>,</div>
                    <div><span className="text-blue-400">proxy_type:</span> <span className="text-green-300">"HTTP"</span>,</div>
                    <div><span className="text-blue-400">inbox_filter:</span> [</div>
                    <div className="ml-4">
                      <span className="text-green-300">"example.com"</span>,
                    </div>
                    <div className="ml-4">
                      <span className="text-green-300">""</span>,
                    </div>
                    <div className="ml-4">
                      <span className="text-green-300">""</span>
                    </div>
                    <div>]</div>
                  </div>
                  <div className="text-purple-400">{'};'}</div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-6">
                <h4 className="text-lg font-semibold mb-4 text-electric-blue">Supported Formats</h4>
                <div className="space-y-3">
                  <div>
                    <div className="text-gray-300 font-semibold">Combolist Format:</div>
                    <div className="bg-gray-900 rounded p-2 font-mono text-sm text-gray-400">
                      email@outlook.com:password123<br />
                      user@hotmail.com:mypassword
                    </div>
                  </div>
                  <div>
                    <div className="text-gray-300 font-semibold">Proxy Formats:</div>
                    <div className="bg-gray-900 rounded p-2 font-mono text-sm text-gray-400">
                      ip:port<br />
                      username:password@hostname:port
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
