import { Card, CardContent } from '@/components/ui/card';

export default function ContactSection() {
  const contactOptions = [
    {
      icon: 'fab fa-github',
      title: 'GitHub',
      description: 'Source code and releases',
      link: 'https://github.com/etherialdev/outlook-checker',
      metric: '97 stars',
      metricColor: 'text-cyber-green'
    },
    {
      icon: 'fab fa-telegram',
      title: 'Developer',
      description: 'Direct support',
      link: 'https://t.me/etherialdev',
      metric: '@etherialdev',
      metricColor: 'text-electric-blue'
    },
    {
      icon: 'fab fa-discord',
      title: 'Discord',
      description: 'Community chat',
      link: 'https://discord.gg/sm38JmvVey',
      metric: 'Join Server',
      metricColor: 'text-cyber-green'
    },
    {
      icon: 'fas fa-broadcast-tower',
      title: 'Channel',
      description: 'Updates and news',
      link: 'https://t.me/etherialhub',
      metric: '@etherialhub',
      metricColor: 'text-electric-blue'
    }
  ];

  return (
    <section id="contact" className="py-20 bg-gray-800/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Get Support</h2>
          <p className="text-xl text-gray-400">Connect with the developer and community</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {contactOptions.map((option, index) => (
            <a 
              key={index}
              href={option.link}
              target="_blank"
              rel="noopener noreferrer"
              className="block"
            >
              <Card className="group bg-gradient-to-br from-gray-800 to-gray-900 border-gray-700 hover:border-ms-blue transition-all hover:transform hover:scale-105 text-center h-full">
                <CardContent className="p-8 flex flex-col justify-center h-full">
                  <div className="text-4xl mb-4 group-hover:text-ms-blue transition-colors">
                    <i className={option.icon}></i>
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{option.title}</h3>
                  <p className="text-gray-400 mb-4 flex-grow">{option.description}</p>
                  <div className={`text-sm ${option.metricColor}`}>{option.metric}</div>
                </CardContent>
              </Card>
            </a>
          ))}
        </div>

        {/* Legal Notice */}
        <div className="mt-16 text-center">
          <Card className="bg-gradient-to-r from-red-900/20 to-orange-900/20 border-red-800/50 max-w-4xl mx-auto">
            <CardContent className="p-6">
              <h4 className="text-lg font-semibold mb-2 text-red-400">⚠️ Legal Notice</h4>
              <p className="text-gray-300 text-sm">
                This tool is for educational purposes only. By using it, you acknowledge that the developer 
                is not liable for any consequences resulting from its use. Ensure compliance with applicable 
                laws and terms of service.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
