import { Card, CardContent } from '@/components/ui/card';

export default function DemoSection() {
  const performanceMetrics = [
    { label: 'Detection Rate:', value: '99.9%', color: 'text-cyber-green' },
    { label: 'Max Threads:', value: '500', color: 'text-electric-blue' },
    { label: 'Retry Limit:', value: 'Configurable', color: 'text-white' },
    { label: 'Proxy Types:', value: 'HTTP/SOCKS4/SOCKS5', color: 'text-white' }
  ];

  const outputCategories = [
    { color: 'bg-green-500', label: 'valid.txt - Valid accounts' },
    { color: 'bg-yellow-500', label: 'locked.txt - Locked accounts' },
    { color: 'bg-blue-500', label: '2fa.txt - 2FA protected' },
    { color: 'bg-red-500', label: 'invalid.txt - Invalid accounts' }
  ];

  return (
    <section id="demo" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Live Demonstration</h2>
          <p className="text-xl text-gray-400">See the tool in action with real-time account verification</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Demo Video/GIF */}
          <div className="relative">
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-8">
                <img 
                  src="https://private-user-images.githubusercontent.com/177364661/408815860-d68cbed8-112d-48fc-b766-9256468a9595.gif?jwt=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3NTMyMDMyODcsIm5iZiI6MTc1MzIwMjk4NywicGF0aCI6Ii8xNzczNjQ2NjEvNDA4ODE1ODYwLWQ2OGNiZWQ4LTExMmQtNDhmYy1iNzY2LTkyNTY0NjhhOTU5NS5naWY_WC1BbXotQWxnb3JpdGhtPUFXUzQtSE1BQy1TSEEyNTYmWC1BbXotQ3JlZGVudGlhbD1BS0lBVkNPRFlMU0E1M1BRSzRaQSUyRjIwMjUwNzIyJTJGdXMtZWFzdC0xJTJGczMlMkZhd3M0X3JlcXVlc3QmWC1BbXotRGF0ZT0yMDI1MDcyMlQxNjQ5NDdaJlgtQW16LUV4cGlyZXM9MzAwJlgtQW16LVNpZ25hdHVyZT03NTgzMzgwYzA3NGM4NjI4MTMzZmNkMzQyZGNjMzE2ZDdkZTUwZGM4Mzc3OTEyNDk5NGVmZmU5MjE5NDJlZTMyJlgtQW16LVNpZ25lZEhlYWRlcnM9aG9zdCJ9.dV66Uh0i9YqrxsuUiMPdKq1sETC0L7P0arti7mBXPwE"
                  alt="Outlook Checker Demo" 
                  className="w-full rounded-lg shadow-2xl" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/50 to-transparent rounded-lg"></div>
                <div className="absolute bottom-4 left-4 bg-cyber-green text-gray-900 px-3 py-1 rounded-full text-sm font-semibold">
                  Live Demo
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Technical Specifications */}
          <div className="space-y-6">
            <h3 className="text-2xl font-bold mb-6">Technical Specifications</h3>
            
            <Card className="bg-gray-800/50 border-gray-700">
              <CardContent className="p-6">
                <h4 className="font-semibold text-lg mb-4 text-ms-blue">Performance Metrics</h4>
                <div className="space-y-3 font-mono text-sm">
                  {performanceMetrics.map((metric, index) => (
                    <div key={index} className="flex justify-between">
                      <span className="text-gray-400">{metric.label}</span>
                      <span className={metric.color}>{metric.value}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gray-800/50 border-gray-700">
              <CardContent className="p-6">
                <h4 className="font-semibold text-lg mb-4 text-ms-blue">Output Categories</h4>
                <div className="space-y-3 font-mono text-sm">
                  {outputCategories.map((category, index) => (
                    <div key={index} className="flex items-center">
                      <div className={`w-3 h-3 ${category.color} rounded-full mr-3`}></div>
                      <span className="text-gray-400">{category.label}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
