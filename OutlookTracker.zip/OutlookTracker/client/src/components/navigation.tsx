import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const NavLinks = ({ isMobile = false, onLinkClick = () => {} }) => (
    <div className={`${isMobile ? 'flex flex-col space-y-4' : 'hidden md:flex items-center space-x-8'}`}>
      <button 
        onClick={() => { scrollToSection('features'); onLinkClick(); }}
        className="text-gray-300 hover:text-ms-blue transition-colors"
      >
        Features
      </button>
      <button 
        onClick={() => { scrollToSection('demo'); onLinkClick(); }}
        className="text-gray-300 hover:text-ms-blue transition-colors"
      >
        Demo
      </button>
      <button 
        onClick={() => { scrollToSection('pricing'); onLinkClick(); }}
        className="text-gray-300 hover:text-ms-blue transition-colors"
      >
        Pricing
      </button>
      <button 
        onClick={() => { scrollToSection('documentation'); onLinkClick(); }}
        className="text-gray-300 hover:text-ms-blue transition-colors"
      >
        Docs
      </button>
      <a href="/checker" onClick={onLinkClick}>
        <Button className="bg-ms-blue hover:bg-ms-blue-dark">
          Try Checker
        </Button>
      </a>
    </div>
  );

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${
      isScrolled ? 'bg-gray-900/90 backdrop-blur-xl' : 'bg-gray-900/80 backdrop-blur-lg'
    } border-b border-gray-800`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <i className="fas fa-shield-alt text-ms-blue text-2xl mr-3"></i>
            <span className="text-xl font-semibold">Outlook Checker</span>
          </div>
          
          <NavLinks />

          {/* Mobile Menu */}
          <div className="md:hidden">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <i className="fas fa-bars text-xl"></i>
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="bg-gray-800 border-gray-700">
                <div className="flex flex-col space-y-6 mt-8">
                  <div className="flex items-center mb-8">
                    <i className="fas fa-shield-alt text-ms-blue text-2xl mr-3"></i>
                    <span className="text-xl font-semibold">Outlook Checker</span>
                  </div>
                  <NavLinks isMobile={true} />
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
}
