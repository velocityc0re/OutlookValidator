export default function Footer() {
  const features = [
    'High-Speed Processing',
    '99.9% Accuracy', 
    'Proxy Support',
    'Smart Detection'
  ];

  const resources = [
    'Documentation',
    'Demo',
    'Pricing', 
    'Support'
  ];

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-gray-900 border-t border-gray-800 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <div className="flex items-center mb-4">
              <i className="fas fa-shield-alt text-ms-blue text-2xl mr-3"></i>
              <span className="text-xl font-semibold">Outlook Checker</span>
            </div>
            <p className="text-gray-400 mb-4">
              Professional Microsoft Outlook & Hotmail account verification tool with industry-leading accuracy.
            </p>
            <div className="flex space-x-4">
              <a 
                href="https://github.com/etherialdev/outlook-checker"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-ms-blue"
              >
                <i className="fab fa-github text-xl"></i>
              </a>
              <a 
                href="https://t.me/etherialdev"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-ms-blue"
              >
                <i className="fab fa-telegram text-xl"></i>
              </a>
              <a 
                href="https://discord.gg/sm38JmvVey"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-ms-blue"
              >
                <i className="fab fa-discord text-xl"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Features</h4>
            <ul className="space-y-2 text-gray-400">
              {features.map((feature, index) => (
                <li key={index}>
                  <button 
                    onClick={() => scrollToSection('features')}
                    className="hover:text-ms-blue transition-colors"
                  >
                    {feature}
                  </button>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Resources</h4>
            <ul className="space-y-2 text-gray-400">
              {resources.map((resource, index) => (
                <li key={index}>
                  <button 
                    onClick={() => scrollToSection(resource.toLowerCase())}
                    className="hover:text-ms-blue transition-colors"
                  >
                    {resource}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2025 Outlook Checker. Licensed under GPL-3.0. Educational use only.</p>
        </div>
      </div>
    </footer>
  );
}
